/*
Importación de módulos
*/
const express = require('express');
const cors = require('cors');
require('dotenv').config();

const { dbConnection } = require('./database/configdb');

// Inicialización de la aplicación
const app = express();

// --- MIDDLEWARES ---
// Lectura y parseo del cuerpo de la petición en formato JSON
app.use(express.json());

// Configuración de CORS
app.use(cors());

// Conexión a la base de datos
dbConnection();

// --- RUTAS ---
app.use('/api/users', require('./routes/users'));

// Abrir la aplicacíon en el puerto 3000
app.listen(process.env.PORT, () => {
    console.log('Servidor corriendo en el puerto ' + process.env.PORT);
});
