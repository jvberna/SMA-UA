const User = require("../models/users"); 
const bcrypt = require("bcryptjs");
const {validationResult} = require("express-validator")

const getUsers = async(req, res) => {
    
    await User.initUsersTable();

    const users = await User.getUsers();

    res.json({
        ok: true,
        msg: "getUsers",
        users
    });
}

const createUser = async (req, res) => {
    const { name, email, password, role } = req.body;

    try {
        const emailExists = await User.getUserByEmail(email);
        if (emailExists) {
            return res.status(400).json({
                ok: false,
                msg: "Email ya existe"
            });
        }

        // Generamos un salt, una cadena aleatoria
        const salt = bcrypt.genSaltSync();
        // y aquí ciframos la contraseña
        const cpassword = bcrypt.hashSync(password, salt);

        // Guardamos el registro en la base de datos SQLite con la nueva contraseña cifrada
        const user = await User.createUser({
            name,
            email,
            password: cpassword,
            role
        });

        res.json({
            ok: true,
            msg: "createUser",
            user,
            // Devolvemos la password original
            pass: password,
            // y la password cifrada para ver las diferencias
            cpass: cpassword
        });
    } catch (error) {
        console.log(error);
        return res.status(400).json({
            ok: false,
            msg: "Error creando usuario"
        });
    }
}

const updateUser = async(req, res) => {
    res.json({
        ok: true,
        msg: 'updateUser'
    });
}

const deleteUser = async(req, res) => {
    res.json({
        ok: true,
        msg: 'deleteUser'
    });
}

module.exports = { getUsers, createUser, updateUser, deleteUser }