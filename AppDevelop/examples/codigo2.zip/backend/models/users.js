const { getDb } = require('../database/configdb');

// Función para inicializar la tabla 'users' si no existe
const initUsersTable = async () => {
    const db = getDb();
    await db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'USER',
            reg_date TEXT NOT NULL DEFAULT (datetime('now')),
            token TEXT
        );
    `);
};

const createUser = async (userData) => {
    const db = getDb();
    const { name, email, password, role = 'USER' } = userData;

    const result = await db.run(
        "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
        [name, email, password, role]
    );

    // Incluimos el id autogenerado junto con los datos recibidos
    return formatUser({
        id: result.lastID,
        ...userData,
        role
    });
};

const getUsers = async () => {
    const db = getDb();
    const users = await db.all("SELECT * FROM users");
    return users.map(user => formatUser(user));
}

const getUserByEmail = async (email) => {
    const db = getDb();
    const user = await db.get("SELECT * FROM users WHERE email = ?", [email]);
    return formatUser(user);
}

// Función personalizada para limpiar datos sensibles del usuario
const formatUser = (user) => {
    if (!user) return null;
    
    // Extraemos password para descartarlo y nos quedamos con el resto
    const { password, ...cleanUser } = user;
    return cleanUser;
};

module.exports = {
    initUsersTable,
    createUser,
    getUsers,
    getUserByEmail
};