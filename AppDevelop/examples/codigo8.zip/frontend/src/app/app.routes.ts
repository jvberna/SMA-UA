import { Routes } from '@angular/router';
import { AuthLayout } from './layouts/auth-layout/auth-layout';
import { AdminLayout } from './layouts/admin-layout/admin-layout';

// Importación de las subrutas de autenticación y administración
import { authRoutes } from './auth/auth.routes';
import { adminRoutes } from './pages/admin.routes';

export const routes: Routes = [
  { 
    path: 'login', 
    component: AuthLayout,
    children: authRoutes 
  },
  { 
    path: 'dashboard', 
    component: AdminLayout,
    children: adminRoutes 
  },
  { path: '', redirectTo: 'login', pathMatch: 'full' },
  { path: '**', redirectTo: 'login' } // Atrapa cualquier ruta global no definida y redirige al login
];