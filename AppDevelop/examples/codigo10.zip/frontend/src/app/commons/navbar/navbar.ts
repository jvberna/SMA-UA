import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';
import { UserService } from '../../services/user';

@Component({
  selector: 'app-navbar',
  imports: [RouterLink],
  templateUrl: './navbar.html',
  styleUrl: './navbar.css',
})
export class Navbar {

  // Inyectamos el servicio de usuarios para poder acceder a la lógica
  // de autenticación sin implementarla directamente en este componente.
  constructor(private userService: UserService) { }

  // Método que se ejecuta al pulsar el botón de "Log out". Su única responsabilidad
  // es delegar el cierre de sesión al UserService.
  logout(): void {
    this.userService.logout();
  }

}