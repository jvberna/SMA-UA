import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-paginator',
  imports: [],
  templateUrl: './paginator.html',
  styleUrl: './paginator.css'
})
export class Paginator {
  // Propiedades de entrada que recibe desde el componente padre (Users)
  @Input() totalItems: number = 0; // Cantidad total de registros en la BD
  @Input() pageSize: number = 10;  // Cantidad de registros por página
  @Input() currentPage: number = 1; // Página en la que nos encontramos actualmente
  
  // Propiedad de salida para notificar al padre cuando el usuario cambia de página
  @Output() pageChange = new EventEmitter<number>();

  // Calcula el número total de páginas dividiendo el total de items entre el tamaño de página
  // Math.ceil redondea hacia arriba (ej: 15 items / 10 = 1.5 -> 2 páginas)
  totalPages(): number {
    return Math.ceil(this.totalItems / this.pageSize);
  }

  // Función ejecutada al hacer clic en Anterior o Siguiente
  changePage(page: number) {
    // Comprobamos que la página solicitada esté dentro de los límites válidos
    // y que no sea la misma en la que ya estamos.
    if (page >= 1 && page <= this.totalPages() && page !== this.currentPage) {
      // Emitimos el número de la nueva página hacia el componente padre
      this.pageChange.emit(page);
    }
  }
}