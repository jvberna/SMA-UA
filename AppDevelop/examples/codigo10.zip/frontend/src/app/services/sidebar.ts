import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class SidebarService {
  // Variable pública que almacena el menú filtrado resultante
  public menu: any[] = [];

  // Método encargado de construir el menú según el perfil
  loadMenu(role: string) {
    const fullMenu = [
      {
        title: 'Dashboard',
        icon: 'mdi mdi-home',
        url: '/dashboard'
      },
      {
        title: 'Users',
        icon: 'mdi mdi-account-multiple',
        url: '/dashboard/users'
      }
    ];

    // Lógica de filtrado: se restringe el acceso a la gestión de usuarios
    if (role === 'ADMIN') {
      this.menu = fullMenu;
    } else {
      this.menu = fullMenu.filter(item => item.title !== 'Users');
    }
  }
}