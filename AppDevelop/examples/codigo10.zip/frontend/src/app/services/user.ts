import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LoginForm } from '../interfaces/login-form';
import { interval, Subscription, throwError } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { Router } from '@angular/router';
import { SidebarService } from './sidebar';

@Injectable({
  providedIn: 'root'
})

export class UserService {

  // Definimos la URL base para no repetirla
  private baseUrl = 'http://localhost:3000/api';
  // Variable para almacenar y controlar el ciclo del temporizador
  private renewalSubscription: Subscription | null = null;

  // Inyectamos el cliente HTTP para futuras peticiones al backend
  constructor(private http: HttpClient, private router: Router, private sidebarService: SidebarService) { }

  // Método para centralizar el guardado de los tokens
  public saveTokens(token: string, tokenR: string): void {
    localStorage.setItem('token', token);
    localStorage.setItem('token_r', tokenR);
  }

  // Métodos para la lectura centralizada de los tokens
  public getToken(): string {
    return localStorage.getItem('token') || '';
  }

  public getRefreshToken(): string {
    return localStorage.getItem('token_r') || '';
  }

  // Recibe los datos del formulario y realiza la petición POST al backend
  login(formData: LoginForm) {
    return this.http.post(`${this.baseUrl}/login`, formData);
  }

  logout() {
    // Obtenemos el token de la memoria
    const token = this.getToken();

    // Lo preparamos en las cabeceras de la petición
    const headers = new HttpHeaders().set('x-token', token);

    // Hacemos la petición enviando las cabeceras
    this.http.get(`${this.baseUrl}/login/logout`, { headers }).subscribe({
      next: () => this.clearSession(),
      error: () => this.clearSession() // Si falla la red, también limpiamos localmente
    });
  }

  // Método auxiliar para no duplicar código
  private clearSession() {
    localStorage.removeItem('token');
    localStorage.removeItem('token_r');
    this.stopTokenRenewalTimer();
    this.router.navigateByUrl('/login');
  }

  // Nuevo método para validar y renovar el token
  renewToken() {
    const tokenR = this.getRefreshToken();

    if (!tokenR) {
      return throwError(() => new Error('No hay token guardado en la memoria'));
    }

    const headers = new HttpHeaders().set('x-token', tokenR);

    return this.http.get(`${this.baseUrl}/login/renew`, { headers }).pipe(
      tap((response: any) => {
        // Cuando la renovación del token finaliza correctamente, utilizamos el rol
        // devuelto por el backend para reconstruir el menú dinámico con las opciones
        // correspondientes al usuario autenticado.
        this.sidebarService.loadMenu(response.user.role);
      }),
      catchError((err) => {
        // Si la API devuelve un error, se fuerza la limpieza
        localStorage.removeItem('token');
        localStorage.removeItem('token_r');

        // Se detiene el temporizador si estuviera en marcha
        this.stopTokenRenewalTimer();

        // Se propaga el error para que las guardas lo capturen y redirijan
        return throwError(() => err);
      })
    );
  }

  // Método para iniciar el temporizador de renovación del token
  // Inicia la ejecución de la renovación cada 5 minutos (300,000 ms)
  startTokenRenewalTimer() {
    // Si ya existe un temporizador en marcha, lo detenemos para evitar procesos duplicados
    this.stopTokenRenewalTimer();

    this.renewalSubscription = interval(300000).subscribe(() => {
      this.renewToken().subscribe({
        next: (response: any) => {
          // Si la respuesta es exitosa, sobrescribimos los tokens antiguos por los nuevos
          localStorage.setItem('token', response.token);
          localStorage.setItem('token_r', response.token_r);
          console.log('Los tokens han sido renovados exitosamente.');
        },
        error: (err) => {
          // Si el token_r ha caducado o el usuario fue eliminado, se detiene el ciclo
          console.error('Error renovando tokens. Es posible que la sesión haya expirado.', err);
          this.stopTokenRenewalTimer();
        }
      });
    });
  }

  // Detiene y destruye el temporizador activo
  stopTokenRenewalTimer() {
    if (this.renewalSubscription) {
      this.renewalSubscription.unsubscribe();
      this.renewalSubscription = null;
    }
  }

  // MÉTODOS PARA LA GESTIÓN DE USUARIOS

  // Obtener lista de usuarios
  getUsers(from: number = 0, search: string = '', sortField: string = 'id', sortOrder: string = 'ASC') {
    const token = this.getToken();
    const headers = new HttpHeaders().set('x-token', token);
    
    // Construimos la URL incluyendo todos los parámetros dinámicos
    const url = `${this.baseUrl}/users?from=${from}&search=${search}&sort=${sortField}&order=${sortOrder}`;
    return this.http.get(url, { headers });
  }

  // Crear un nuevo usuario
  createUser(userData: any) {
    const token = this.getToken();
    const headers = new HttpHeaders().set('x-token', token);
    return this.http.post(`${this.baseUrl}/users`, userData, { headers });
  }

  // Actualizar un usuario existente
  updateUser(id: string | number, userData: any) {
    const token = this.getToken();
    const headers = new HttpHeaders().set('x-token', token);
    return this.http.put(`${this.baseUrl}/users/${id}`, userData, { headers });
  }

  updateUserPassword(id: string | number, passwordData: any) {
    const token = this.getToken();
    const headers = new HttpHeaders().set('x-token', token);
    return this.http.put(`${this.baseUrl}/users/${id}/password`, passwordData, { headers });
  }

  // Eliminar un usuario
  deleteUser(id: string | number) {
    const token = this.getToken();
    const headers = new HttpHeaders().set('x-token', token);
    return this.http.delete(`${this.baseUrl}/users/${id}`, { headers });
  }
}