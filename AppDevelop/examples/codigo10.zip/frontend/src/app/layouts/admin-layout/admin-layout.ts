import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Sidebar } from '../../commons/sidebar/sidebar';
import { Navbar } from '../../commons/navbar/navbar';
import { Breadcrumb } from '../../commons/breadcrumb/breadcrumb';

@Component({
  selector: 'app-admin-layout',
  imports: [RouterOutlet, Sidebar, Navbar, Breadcrumb],
  templateUrl: './admin-layout.html',
  styleUrl: './admin-layout.css'
})
export class AdminLayout {}