import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { UserService } from '../services/user';

export const authGuard: CanActivateFn = (route, state): Observable<boolean> => {
  // Extraemos los servicios necesarios mediante inyección de dependencias funcional
  const userService = inject(UserService);
  const router = inject(Router);

  // Llamamos al método del servicio que comprueba el token contra el backend
  return userService.renewToken().pipe(

    // Si el servidor responde correctamente, la sesión es válida: permitimos el acceso
    map(() => true),

    // Si ocurre un error (token caducado, modificado o usuario eliminado en BD):
    catchError(() => {
      // Detenemos la navegación y redirigimos al usuario a la pantalla de login
      router.navigateByUrl('/login');

      // Retornamos 'false' para bloquear definitivamente la activación de la ruta privada
      return of(false);
    })
  );
};