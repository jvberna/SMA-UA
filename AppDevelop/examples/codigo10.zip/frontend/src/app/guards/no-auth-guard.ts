import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';
import { Observable, of } from 'rxjs';
import { map, catchError } from 'rxjs/operators';
import { UserService } from '../services/user';

export const noAuthGuard: CanActivateFn = (route, state): Observable<boolean> => {
  const userService = inject(UserService);
  const router = inject(Router);

  return userService.renewToken().pipe(
    map(() => {
      // Si hay sesión, lo enviamos al dashboard y bloqueamos la vista de login
      router.navigateByUrl('/dashboard');
      return false;
    }),
    catchError(() => {
      // Si no hay sesión, dejamos que cargue el login
      return of(true);
    })
  );
};