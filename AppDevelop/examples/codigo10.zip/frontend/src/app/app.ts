import { Component, OnInit, signal } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { Footer } from './commons/footer/footer';
import { UserService } from './services/user';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet, Footer],
  templateUrl: './app.html',
  styleUrl: './app.css'
})
export class App implements OnInit {
  protected readonly title = signal('frontend');

  // Inyectamos el servicio en el constructor
  constructor(private userService: UserService) {}

  // Implementamos el método del ciclo de vida OnInit
  ngOnInit() {
    // Si la memoria contiene un token de renovación, reactivamos el temporizador al cargar la aplicación
    if (localStorage.getItem('token_r')) {
      this.userService.startTokenRenewalTimer();
    }
  }
}