import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { UserService } from '../../services/user';
import { Paginator } from '../../commons/paginator/paginator';
import { UserForm } from './user-form/user-form';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-users',
  imports: [FormsModule, Paginator, UserForm],
  templateUrl: './users.html',
  styleUrl: './users.css'
})
export class Users implements OnInit {
  // Variables para la respuesta de la base de datos
  public users: any[] = [];
  public totalUsers: number = 0;
  
  // Variables de control de paginación y búsqueda
  public from: number = 0;
  public limit: number = 10;
  public currentPage: number = 1;
  public searchQuery: string = '';
  public sortField: string = '';
  public sortOrder: string = '';

  // Variables de control de la vista para alternar componentes
  public showForm: boolean = false;
  public selectedUser: any = null;
  public editingPassword: boolean = false;

  // Inyectamos el servicio de usuarios y el detector de cambios
  constructor(private userService: UserService, private cdr: ChangeDetectorRef) {}

  ngOnInit(): void {
    // Cargamos los usuarios al iniciar el componente
    this.loadUsers();
  }

  // Método principal de consulta de datos
  loadUsers() {
    // Enviamos todas las variables de estado al servicio
    this.userService.getUsers(this.from, this.searchQuery, this.sortField, this.sortOrder).subscribe({
      next: (res: any) => {
        // Almacenamos los resultados devueltos por el backend
        this.users = res.users;
        this.totalUsers = res.page.total;
        
        // Forzamos la actualización de la vista HTML para evitar retrasos visuales
        // ocasionados por el ciclo de vida de Angular.
        this.cdr.detectChanges(); 
      },
      error: (err) => console.error(err)
    });
  }

  // Método ejecutado al buscar texto
  searchUsers() {
    this.from = 0; // Reiniciamos la paginación a cero
    this.currentPage = 1;
    this.loadUsers(); // Ejecutamos la carga con el nuevo texto almacenado
  }

  // Método ejecutado al hacer clic en las cabeceras de la tabla
  sortBy(field: string) {
    if (this.sortField === field) {
      // Si hacemos clic en la misma columna, invertimos el orden
      this.sortOrder = this.sortOrder === 'ASC' ? 'DESC' : 'ASC';
    } else {
      // Si cambiamos de columna, establecemos el nuevo campo y orden ascendente
      this.sortField = field;
      this.sortOrder = 'ASC';
    }
    this.from = 0; // Reiniciamos la paginación a cero tras reordenar
    this.currentPage = 1;
    this.loadUsers();
  }

  // Método disparado por el componente Paginator
  onPageChange(page: number) {
    this.currentPage = page;
    // Calculamos el desfase (offset) matemático multiplicando la página anterior por el límite
    this.from = (page - 1) * this.limit;
    this.loadUsers();
  }

  // Funciones de apertura y cierre de formularios modificando las variables de estado
  openCreateForm() {
    this.selectedUser = null;
    this.editingPassword = false;
    this.showForm = true;
  }

  openEditForm(user: any) {
    this.selectedUser = user;
    this.editingPassword = false;
    this.showForm = true;
  }

  openPasswordForm(user: any) {
    this.selectedUser = user;
    this.editingPassword = true;
    this.showForm = true;
  }

  hideUserForm() {
    this.showForm = false;
    this.selectedUser = null;
    this.editingPassword = false;
  }

  // Recepción del evento de guardado emitido por el formulario
  saveUser(formData: any) {
    if (this.editingPassword) {
      // Llamada a la ruta PUT de contraseñas
      this.userService.updateUserPassword(this.selectedUser.id, formData).subscribe({
        next: () => {
          Swal.fire('Actualizada', 'Contraseña actualizada correctamente', 'success');
          this.hideUserForm();
        },
        error: (err) => Swal.fire('Error', err.error.msg, 'error')
      });
    } else if (this.selectedUser) {
      // Llamada a la ruta PUT de datos generales
      this.userService.updateUser(this.selectedUser.id, formData).subscribe({
        next: () => {
          Swal.fire('Actualizado', 'Usuario actualizado correctamente', 'success');
          this.hideUserForm();
          this.loadUsers();
        },
        error: (err) => Swal.fire('Error', err.error.msg, 'error')
      });
    } else {
      // Llamada a la ruta POST de creación
      this.userService.createUser(formData).subscribe({
        next: () => {
          Swal.fire('Creado', 'Usuario creado correctamente', 'success');
          this.hideUserForm();
          this.loadUsers();
        },
        error: (err) => Swal.fire('Error', err.error.msg, 'error')
      });
    }
  }

  // Método de eliminación con cuadro de confirmación
  deleteUser(id: string | number) {
    Swal.fire({
      title: '¿Estás seguro?',
      text: "Esta acción eliminará permanentemente al usuario.",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Sí, borrar',
      cancelButtonText: 'Cancelar'
    }).then((result) => {
      // Si el usuario acepta la alerta, procedemos con el borrado
      if (result.isConfirmed) {
        this.userService.deleteUser(id).subscribe({
          next: () => {
            Swal.fire('Borrado', 'El usuario ha sido eliminado.', 'success');
            
            // Lógica de corrección visual: si borramos el único registro que quedaba 
            // en la última página, forzamos un retroceso de página.
            if (this.users.length === 1 && this.currentPage > 1) {
              this.from -= this.limit;
              this.currentPage -= 1;
            }
            this.loadUsers(); // Recargamos la tabla para confirmar los cambios
          },
          error: (err) => Swal.fire('Error', err.error.msg, 'error')
        });
      }
    });
  }
}