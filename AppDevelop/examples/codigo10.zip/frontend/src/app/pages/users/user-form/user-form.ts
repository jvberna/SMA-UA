import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
 
@Component({
  selector: 'app-user-form',
  imports: [ReactiveFormsModule],
  templateUrl: './user-form.html',
  styleUrl: './user-form.css'
})
export class UserForm implements OnInit {
  // Variables de entrada para determinar el modo del formulario
  @Input() user: any = null; // Si contiene datos, estamos editando. Si es null, creando.
  @Input() editPasswordOnly: boolean = false; // Flag para el modo de cambio de contraseña
  
  // Eventos de salida para comunicarnos con el padre
  @Output() save = new EventEmitter<any>();
  @Output() cancel = new EventEmitter<void>();
  
  // Declaración del grupo del formulario reactivo
  public userForm: FormGroup;

  constructor(private fb: FormBuilder) {
    // Definimos la estructura base inicial con todos los campos posibles
    this.userForm = this.fb.group({
      name: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      password: [''],
      role: ['USER', Validators.required]
    });
  }

  ngOnInit(): void {
    if (this.editPasswordOnly) {
      // MODO 1: Cambio exclusivo de contraseña
      // Eliminamos los controles de datos generales para que no den error de validación
      this.userForm.removeControl('name');
      this.userForm.removeControl('email');
      this.userForm.removeControl('role');
      this.userForm.removeControl('password'); // Eliminamos el password genérico
      
      // Añadimos los controles específicos requeridos por nuestra API para esta acción
      this.userForm.addControl('oldPassword', this.fb.control('', [Validators.required]));
      this.userForm.addControl('newPassword', this.fb.control('', [Validators.required]));
      
    } else if (this.user) {
      // MODO 2: Edición de datos generales
      // Rellenamos el formulario con los datos existentes del usuario
      this.userForm.patchValue({
        name: this.user.name,
        email: this.user.email,
        role: this.user.role || 'USER'
      });
      // Eliminamos el control de la contraseña porque no se modifica desde aquí
      this.userForm.removeControl('password');
      
    } else {
      // MODO 3: Creación de un nuevo usuario
      // Mantenemos la estructura base, pero hacemos que el campo de contraseña sea obligatorio
      this.userForm.get('password')?.setValidators([Validators.required]);
      this.userForm.get('password')?.updateValueAndValidity();
    }
  }
  
  onSubmit() {
    // Si todos los campos cumplen las validaciones, emitimos el valor del formulario
    if (this.userForm.valid) {
      this.save.emit(this.userForm.value);
    }
  }
  
  onCancel() {
    // Emitimos el evento de cancelación para que el padre cierre la vista
    this.cancel.emit();
  }
}