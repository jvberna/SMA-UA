import { Component, OnInit } from '@angular/core';
import { UserService } from '../../services/user';

@Component({
  selector: 'app-dashboard',
  imports: [],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css',
})
export class Dashboard implements OnInit {
  // Variable pública para mostrar el rol en la vista HTML
  public role: string = '';

  // Inyectamos el servicio para tener acceso a los métodos de lectura del token
  constructor(private userService: UserService) {}

  ngOnInit(): void {
    const token = this.userService.getToken();
    
    if (token) {
      // Extraemos el cuerpo (payload) del JWT, que es la segunda parte separada por un punto
      const payload = token.split('.')[1];
      
      // Decodificamos el texto en Base64 y lo convertimos a un objeto JSON evaluable
      const decoded = JSON.parse(atob(payload));
      
      // Asignamos el rol resultante a la variable de la vista
      this.role = decoded.role;
    }
  }
}