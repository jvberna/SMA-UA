import { Component, OnInit } from '@angular/core'; // 1. Añadimos OnInit
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../services/user';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';
import { SidebarService } from '../../services/sidebar';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login implements OnInit { // 2. Implementamos OnInit

  public loginForm: FormGroup;
  public formSubmit: boolean = false;

  // Inyectamos el servicio junto al FormBuilder y también el Router
  constructor(private fb: FormBuilder, private userService: UserService, private router: Router, private sidebarService: SidebarService) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
  }

  // 3. Añadimos el ciclo de vida inicial para comprobar la sesión
  ngOnInit(): void {
    this.userService.renewToken().subscribe({
      next: (response: any) => {
        // Carga el menú si ya había una sesión válida
        this.sidebarService.loadMenu(response.user.role);
        // Si el token es válido, evitamos que vea el login y lo enviamos al dashboard
        this.router.navigateByUrl('/dashboard');
      },
      error: () => {
        // Si no hay token o caducó, se ignora y el componente renderiza el formulario
      }
    });
  }

  // Comprueba si el campo es válido o si aún no se ha intentado enviar
  isFieldValid(field: string): boolean {
    return this.loginForm.get(field)?.valid || !this.formSubmit;
  }

  login() {
    // Registramos que el usuario ha intentado enviar el formulario
    this.formSubmit = true;

    // Si el formulario no es válido, detenemos la ejecución para evitar
    // realizar una petición innecesaria al servidor.
    if (!this.loginForm.valid) {
      console.log('Error: Campos incompletos o con formato incorrecto.');
      return;
    }

    // Delegamos la acción al servicio, enviando el objeto con email y password
    this.userService.login(this.loginForm.value)
    .subscribe({
      next: (response: any) => {
        // Invocamos la función saveTokens de nuestro UserService para que esta gestione su almacenamiento
        this.userService.saveTokens(response.token, response.token_r);

        // Iniciamos el temporizador de renovación en segundo plano
        this.userService.startTokenRenewalTimer();

        // Carga el menú tras un inicio de sesión exitoso
        this.sidebarService.loadMenu(response.user.role);

        // Redirigimos al usuario a la zona privada
        this.router.navigateByUrl('/dashboard');
      },
      error: (err) => {
        // Si se produce un error durante la autenticación, mostramos una alerta al usuario
        Swal.fire({
          icon: 'error',
          title: 'Error',
          text: err.error.msg || 'No pudo completarse la petición, por favor inténtelo más tarde',
          confirmButtonText: 'OK',
          confirmButtonColor: '#d33'
        });
      }
    });
  }
}