const { response } = require('express');
// Lista de roles permitidos.
// Si alguien envía un rol que no está aquí, dará error.
const roleList = [ 'USER', 'ADMIN' ];

// Comprueba si el rol enviado es válido
const validateRole = (req, res = response, next) => {
    const role = req.body.role;

    if (role && !roleList.includes(role)) {
        return res.status(400).json({
            ok: false,
            msg: 'Rol no permitido'
        });
    }

    next();
};

module.exports = {
    validateRole
};