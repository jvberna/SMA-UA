const jwt = require('jsonwebtoken');

// Middleware para verificar la validez del JWT en las peticiones HTTP
const validateJWT = (req, res, next) => {
    // Extraemos el token enviado en los encabezados de la petición
    const token = req.header('x-token');

    // Si no se proporciona token, se interrumpe la petición
    if (!token) {
        return res.status(401).json({
            ok: false,
            msg: 'No hay token en la petición'
        });
    }

    try {
        // Comprobamos la firma del token utilizando la clave secreta del entorno
        const { id, role } = jwt.verify(token, process.env.JWTSECRET);
        
        // Guardamos el identificador y el rol en el objeto de la petición (req)
        req.id = id;
        req.role = role;

        // Permitimos que la ejecución continúe hacia el siguiente middleware o controlador
        next();

    } catch (error) {
        return res.status(401).json({
            ok: false,
            msg: 'Token no válido'
        });
    }
};

module.exports = { validateJWT };