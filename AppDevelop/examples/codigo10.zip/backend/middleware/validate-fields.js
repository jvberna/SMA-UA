const { response } = require('express');
const { validationResult } = require('express-validator');

const validateFields = (req, res = response, next) => {
    const errorVal = validationResult(req);
    if (!errorVal.isEmpty()) {
        return res.status(400).json({
            ok: false,
            errores: errorVal.mapped()
        });
    }
    next();
}

module.exports = { validateFields }