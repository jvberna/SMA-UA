const { Router } = require('express');
const { check } = require('express-validator');
const { getUsers, createUser, updateUser, updateUserPassword, deleteUser } = require('../controllers/users');
const { validateFields } = require('../middleware/validate-fields');
const { validateRole } = require('../middleware/validate-role');
const { validateJWT } = require('../middleware/validate-jwt');

const router = Router();

router.get('/', validateJWT, getUsers);

router.post('/', [
    validateJWT,
    check('name', 'El argumento name es obligatorio').not().isEmpty(),
    check('email', 'El argumento email es obligatorio').not().isEmpty(),
    check('password', 'El argumento password es obligatorio').not().isEmpty(),
    validateFields,
    validateRole
], createUser);

// Tanto el PUT como el DELETE que estamos empleando necesitan una id de usuario, que estaría en la URL. Esto se puede saber observando que en vez de "/" pone "/:id".
// Ejemplo: /api/users/123456. 123456 sería la id que se le pasaría a la request como parámetro del campo id.

// Este método actualiza los campos de un usuario ya existente, que se especificaría con la id correspondiente.
router.put('/:id', [
    validateJWT,
    check('name', 'El argumento name es obligatorio').not().isEmpty(),
    check('email', 'El argumento email es obligatorio').not().isEmpty(),
    check('id', 'El identificador no es válido').isInt(),
    validateFields,
    validateRole
], updateUser);

// Este método actualiza únicamente la contraseña de un usuario existente.
router.put('/:id/password', [
    validateJWT,
    check('oldPassword', 'La contraseña antigua es obligatoria').not().isEmpty(),
    check('newPassword', 'La nueva contraseña es obligatoria').not().isEmpty(),
    check('id', 'El identificador no es válido').isInt(),
    validateFields,
    validateRole
], updateUserPassword);

// Este método borrar un usuario existente, que se especificaría con la id correspondiente.
router.delete('/:id', [
    validateJWT,
    check('id', 'El identificador no es válido').isInt(),
    validateFields
], deleteUser);

module.exports = router;