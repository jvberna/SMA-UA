const User = require("../models/users"); 
const bcrypt = require("bcryptjs");

const getUsers = async (req, res) => {
    try {
        await User.initUsersTable();

        // Extraemos los parámetros de la URL, asignando valores por defecto si no existen
        const from = Number(req.query.from) || 0;
        const regPerPage = 10;
        const search = req.query.search || '';
        const sort = req.query.sort || 'id';
        const order = req.query.order || 'ASC';

        // Ejecutamos ambas consultas pasando los parámetros de búsqueda y ordenación
        const [ users, countResult ] = await Promise.all([
            User.getUsersWithToken(from, regPerPage, search, sort, order),
            User.countUsers(search)
        ]);

        // Extraemos el número directamente de la propiedad 'total' que definimos en el SELECT de SQLite
        const totalRecords = countResult.total || 0;

        res.json({
            ok: true,
            msg: "getUsers",
            users,
            page: {
                from,
                regPerPage,
                total: totalRecords
            }
        });

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: "Error obteniendo usuarios"
        });
    }
};

const createUser = async (req, res) => {
    const { name, email, password, role } = req.body;

    try {
        const emailExists = await User.getUserByEmail(email);
        if (emailExists) {
            return res.status(400).json({
                ok: false,
                msg: "Email ya existe"
            });
        }

        // Generamos un salt, una cadena aleatoria
        const salt = bcrypt.genSaltSync();
        // y aquí ciframos la contraseña
        const cpassword = bcrypt.hashSync(password, salt);

        // Guardamos el registro en la base de datos SQLite con la nueva contraseña cifrada
        const user = await User.createUser({
            name,
            email,
            password: cpassword,
            role
        });

        res.json({
            ok: true,
            msg: "createUser",
            user,
            // Devolvemos la password original
            pass: password,
            // y la password cifrada para ver las diferencias
            cpass: cpassword
        });
    } catch (error) {
        console.log(error);
        return res.status(400).json({
            ok: false,
            msg: "Error creando usuario"
        });
    }
}

const updateUser = async (req, res) => {
    const { id } = req.params;

    // Descartamos la contraseña por seguridad y extraemos el email para su validación
    const { password, email, ...object } = req.body;

    try {
        // Comprobamos la existencia del usuario
        const user = await User.getUserById(id);
        if (!user) {
            return res.status(404).json({
                ok: false,
                msg: "No existe un usuario con ese identificador"
            });
        }

        // Comprobamos la disponibilidad del correo electrónico
        const emailExists = await User.getUserByEmail(email);
        if (emailExists && emailExists.id !== Number(id)) {
            return res.status(400).json({
                ok: false,
                msg: "El correo electrónico ya pertenece a otro usuario"
            });
        }

        // Asignamos el correo verificado
        object.email = email;

        // Ejecutamos la actualización
        const updatedUser = await User.updateUser(id, object);

        res.json({
            ok: true,
            msg: "updateUser",
            user: updatedUser
        });

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: "Error actualizando el usuario"
        });
    }
};

const updateUserPassword = async (req, res) => {
    const { id } = req.params;
    const { oldPassword, newPassword } = req.body;

    try {
        // Usamos la nueva función para recuperar el usuario con su contraseña cifrada
        const user = await User.getUserByIdWithPassword(id);
        
        if (!user) {
            return res.status(404).json({
                ok: false,
                msg: "No existe un usuario con ese identificador"
            });
        }

        // Comparamos la contraseña antigua introducida con la que hay en la base de datos
        const validPassword = bcrypt.compareSync(oldPassword, user.password);
        if (!validPassword) {
            return res.status(400).json({
                ok: false,
                msg: "La contraseña antigua es incorrecta"
            });
        }

        // Si es válida, ciframos la nueva contraseña
        const salt = bcrypt.genSaltSync();
        const cpassword = bcrypt.hashSync(newPassword, salt);

        // Actualizamos en la base de datos
        await User.updateUserPassword(id, cpassword);

        res.json({
            ok: true,
            msg: "Contraseña actualizada correctamente"
        });

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: "Error actualizando la contraseña"
        });
    }
};

const deleteUser = async (req, res) => {
    const { id } = req.params;

    try {
        const user = await User.getUserById(id);
        if (!user) {
            return res.status(400).json({
                ok: false,
                msg: "El usuario no existe"
            });
        }

        const deletedUser = await User.deleteUser(id);

        res.json({
            ok: true,
            msg: "Usuario eliminado",
            user: deletedUser
        });

    } catch (error) {
        console.log(error);
        return res.status(500).json({
            ok: false,
            msg: "Error borrando usuario"
        });
    }
};

module.exports = { getUsers, createUser, updateUser, updateUserPassword, deleteUser }