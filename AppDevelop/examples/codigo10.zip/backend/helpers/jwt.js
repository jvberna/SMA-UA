const jwt = require('jsonwebtoken');

// Genera el token de acceso (corta duración) y el token de renovación (larga duración)
const generateJWT = (id, role) => {
    return new Promise((resolve, reject) => {
        const payload = { id, role };

        // 1. Token de acceso (15 minutos)
        jwt.sign(
            payload,
            process.env.JWTSECRET,
            { expiresIn: '15m' },
            (err, token) => {
                if (err) return reject('No se pudo generar el token de acceso');

                // 2. Token de renovación (24 horas)
                jwt.sign(
                    payload,
                    process.env.JWTSECRET,
                    { expiresIn: '24h' },
                    (errR, token_r) => {
                        if (errR) return reject('No se pudo generar el token de renovación');
                        
                        // Devolvemos ambos tokens
                        resolve({ token, token_r });
                    }
                );
            }
        );
    });
};

module.exports = { generateJWT };