import { Component } from '@angular/core';
import { ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UserService } from '../../services/user';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './login.html',
  styleUrl: './login.css'
})
export class Login {
  
  public loginForm: FormGroup;
  public formSubmit: boolean = false;

  // Inyectamos el servicio junto al FormBuilder
  constructor(private fb: FormBuilder, private userService: UserService) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required]]
    });
  }

  // Comprueba si el campo es válido o si aún no se ha intentado enviar
  isFieldValid(field: string): boolean {
    return this.loginForm.get(field)?.valid || !this.formSubmit;
  }

  login() {
    // Registramos que el usuario ha intentado enviar el formulario
    this.formSubmit = true;

    if (this.loginForm.valid) {
      // Delegamos la acción al servicio, enviando el objeto con email y password
      this.userService.login(this.loginForm.value).subscribe({
        next: (response) => {
          // El backend ha validado las credenciales y devuelve el JWT
          console.log('Login exitoso. Respuesta del servidor:', response);
        },
        error: (err) => {
          // El backend rechaza el acceso o hay un problema de conexión
          console.warn('Error en la petición de login:', err);
        }
      });
    } else {
      console.log('Error: Campos incompletos o con formato incorrecto.');
    }
  }
}