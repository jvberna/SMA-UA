import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  // Inyectamos el cliente HTTP para futuras peticiones al backend
  constructor(private http: HttpClient) { }

  // Recibe los datos del formulario y realiza la petición POST al backend
  login(formData: any) {
    return this.http.post('http://localhost:3000/api/login', formData);
  }
}