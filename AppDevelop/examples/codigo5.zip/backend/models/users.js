const { getDb } = require('../database/configdb');

// Función para inicializar la tabla 'users' si no existe
const initUsersTable = async () => {
    const db = getDb();
    await db.exec(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            email TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'USER',
            reg_date TEXT NOT NULL DEFAULT (datetime('now')),
            token TEXT
        );
    `);
};


const getUsers = async (from = 0, limit = 10) => {
    const db = getDb();
    const users = await db.all(
        "SELECT * FROM users LIMIT ? OFFSET ?",
        [limit, from]
    );
    return users.map(user => formatUser(user));
}

const getUserByEmail = async (email) => {
    const db = getDb();
    const user = await db.get("SELECT * FROM users WHERE email = ?", [email]);
    return formatUser(user);
}

// Hace lo mismo que getUserByEmail pero devuelve la contraseña, de forma que lo podemos utilizar para el login
const getUserByEmailWithPassword = async (email) => {
    const db = getDb();
    return await db.get("SELECT * FROM users WHERE email = ?", [email]);
}

const getUserById = async (id) => {
    const db = getDb();
    const user = await db.get("SELECT * FROM users WHERE id = ?", [id]);
    return formatUser(user);
}

const createUser = async (userData) => {
    const db = getDb();
    const { name, email, password, role = 'USER' } = userData;

    const result = await db.run(
        "INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)",
        [name, email, password, role]
    );

    // Incluimos el id autogenerado junto con los datos recibidos
    return formatUser({
        id: result.lastID,
        ...userData,
        role
    });
};

// Actualizar los datos del usuario en la base de datos
const updateUser = async (id, userData) => {
    const db = getDb();
    const { name, email, role = 'USER' } = userData;

    await db.run(
        "UPDATE users SET name = ?, email = ?, role = ? WHERE id = ?",
        [name, email, role, id]
    );

    const updatedUser = await getUserById(id);
    return formatUser(updatedUser);
};

// Borrar un usuario de la base de datos
const deleteUser = async (id) => {
    const db = getDb();
    const user = await getUserById(id);
    if (!user) return null;

    await db.run("DELETE FROM users WHERE id = ?", [id]);
    return formatUser(user);
};

// Función personalizada para limpiar datos sensibles del usuario
const formatUser = (user) => {
    if (!user) return null;
    
    // Extraemos password para descartarlo y nos quedamos con el resto
    const { password, ...cleanUser } = user;
    return cleanUser;
};

// Actualiza el token activo en la BD para garantizar una única sesión abierta
const updateUserToken = async (id, token) => {
    const db = getDb();
    await db.run("UPDATE users SET token = ? WHERE id = ?", [token, id]);
};

// Cuenta el total de usuarios en la tabla
const countUsers = async () => {
    const db = getDb();
    return await db.get("SELECT COUNT(*) as total FROM users");
};

module.exports = {
    initUsersTable,
    getUsers,
    getUserByEmail,
    getUserByEmailWithPassword,
    getUserById,
    createUser,
    updateUser,
    deleteUser,
    updateUserToken,
    countUsers
};