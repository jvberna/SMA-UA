const { Router } = require('express');
// Importamos la función login del archivo /controllers/auth.js
const { login, renewToken } = require('../controllers/auth');
// Importamos la función check para poner las condiciones a los parámetros de las consultas
const { check } = require('express-validator');
// Función que creamos anteriormente para imprimir los errores de la solicitud en la respuesta
const { validateFields } = require('../middleware/validate-fields');
const { validateJWT } = require('../middleware/validate-jwt');

const router = Router();

router.post('/', [
    check('password', 'El argumento password es obligatorio').not().isEmpty(),
    check('email', 'El argumento email es obligatorio').not().isEmpty(),
    validateFields,
], login);

router.get('/renew', validateJWT, renewToken);

module.exports = router;