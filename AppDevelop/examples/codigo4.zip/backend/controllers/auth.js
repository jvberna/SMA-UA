const { response } = require('express');
const bcrypt = require('bcryptjs');
const User = require('../models/users');
// Importamos la función para generar el token JWT
const { generateJWT } = require('../helpers/jwt');

// Función que lleva a cabo el login y devuelve un token
const login = async(req, res = response) => {
    
    const { email, password } = req.body;
    
    try {
        const user = await User.getUserByEmailWithPassword(email);
        if (!user) {
            return res.status(400).json({
                ok: false,
                msg: 'Usuario o contraseña incorrectos',
                token: ''
            });
        }

        const validPassword = bcrypt.compareSync(password, user.password);
        if (!validPassword) {
            return res.status(400).json({
                ok: false,
                msg: 'Usuario o contraseña incorrectos',
                token: ''
            });
        }

        // Generamos ambos tokens
        const { token, token_r } = await generateJWT(user.id, user.role);

        // Guardamos el token de acceso en SQLite para el control de sesión única
        await User.updateUserToken(user.id, token);

        // 1. Obtenemos el usuario limpio (sin contraseña) ya que el user anteriormente declarado, trae la contraseña cifrada, y eso sería una brecha de seguridad
        const cleanUser = await User.getUserById(user.id);

        // 2. Enviamos 'cleanUser' en la respuesta
        res.json({
            ok: true,
            user: cleanUser,
            token,
            token_r
        });
        
    } catch (error) {
        console.log(error);
        return res.status(400).json({
            ok: false,
            msg: 'Error en login',
            token: ''
        });
    }
}

// Función para renovar el token de acceso cuando se requiere
const renewToken = async (req, res = response) => {
    const id = req.id;

    try {
        // Generamos un nuevo par de tokens
        const { token, token_r } = await generateJWT(id, req.role);

        // Actualizamos la base de datos con el nuevo token activo
        await User.updateUserToken(id, token);

        const user = await User.getUserById(id);

        res.json({
            ok: true,
            user,
            token,
            token_r
        });
    } catch (error) {
        console.log(error);
        res.status(500).json({
            ok: false,
            msg: 'Error al renovar el token'
        });
    }
};

module.exports = { login, renewToken };